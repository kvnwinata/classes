6.837 Project 1

1. Go to the working directory, run make, and run ./a1 <objectname>.swp
2. No.
3. Lecture slides.
4. No.
5. Yes, I fixed the closed curve problem where the ends don't line up. weirder.swp is now rendered as a seamless solid.
6. It was a lot of math, but it was fun.